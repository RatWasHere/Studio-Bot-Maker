var Convert = require("ansi-to-html");
var convert = new Convert();
