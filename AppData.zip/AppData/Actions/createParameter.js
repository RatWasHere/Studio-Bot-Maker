module.exports = {
    data: {"name":"Create Parameter", "paramName":"", "paramDesc":"", "button":"✕", "choice":"String"},
    UI: {"compatibleWith": ["None"], "text": "Create Parameter","sepbar":"sbar", "btext1":"Parameter Title", "input43":"paramName", "preview":"paramName", "btext4":"Parameter Description", "input66":"paramDesc", "previewName":"Name", "menuBar": {choices: ["String", "Boolean", "Channel", "User", "Integer"], storeAs: "choice"},"btext666666":"Require Parameter", "ButtonBar":{buttons: ["✓", "✕"]}},
    run() {
        null
    }
}