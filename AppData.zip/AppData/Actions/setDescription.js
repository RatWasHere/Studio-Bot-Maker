module.exports = {
    data: {"name": "Set Description","desc": "", "varble": ""},
    UI: {"compatibleWith": ["Slash"], "text1":"Set Description ",  "largeInput":"desc", "sepbar2":"sepber","btext1":"Variable Name","input333":"varble",previewName: "Content", preview: "desc"},
    run(values, message, uID) {
        
    }
}