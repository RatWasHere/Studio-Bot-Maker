module.exports = {
    data: {"name":"Modify Command", "description":""},
    UI: {"compatibleWith":["Slash"], "text": "Modify Command","sepbar":"sbar", "btext1":"Slash Command Description", "input":"description", "preview":"description", "previewName":"Description"},
    run() {
        null
    }
}