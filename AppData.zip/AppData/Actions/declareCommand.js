module.exports = {
    data: {"name":"Declare Command", "cmd":"DEPRECATED", "menuBr":"Achoice1"},
    UI: {"compatibleWith": ["Slash"], "text": "Declare Slash Command","sepbar":"sbar", "btext1":"This action is deprecated. It will do literally nothing.", "preview":"cmd", "previewName":"DEPRECATED"},
    run() {
        null
    }
}